# VERCEL DEPLOYMENT - STEP BY STEP

## WHAT WAS FIXED

**The Problem:** Your `vite.config.js` had `base: '/fixd-terminal/'` which is for GitHub Pages. Vercel needs `base: '/'`.

**The Fix:** Changed base path to '/' — your project is now Vercel-ready.

---

## DEPLOYMENT INSTRUCTIONS (5 MINUTES)

### STEP 1: Push to GitHub

If your code isn't on GitHub yet:

```bash
cd /path/to/fixd-terminal
git init
git add .
git commit -m "Initial commit - FIXD Terminal"
git branch -M main
git remote add origin https://github.com/Amadoubbah/fixd-terminal.git
git push -u origin main
```

**Make sure the repo is public** (Settings → Danger Zone → Change visibility → Public)

---

### STEP 2: Sign Up for Vercel

1. Go to **[vercel.com](https://vercel.com)**
2. Click **"Sign Up"**
3. Choose **"Continue with GitHub"**
4. Authorize Vercel to access your repositories

---

### STEP 3: Import Your Project

1. In Vercel dashboard, click **"Add New..." → "Project"**
2. Find **"fixd-terminal"** in your repository list
3. Click **"Import"**

---

### STEP 4: Configure Build Settings

Vercel should auto-detect everything, but verify:

- **Framework Preset:** Vite
- **Build Command:** `npm run build`
- **Output Directory:** `dist`
- **Install Command:** `npm install`

**DO NOT CHANGE ANYTHING ELSE**

Root Directory: Leave blank  
Environment Variables: Skip for now (AI memo won't work, but everything else will)

---

### STEP 5: Deploy

1. Click **"Deploy"**
2. Wait 2-3 minutes while Vercel builds your app
3. You'll see **"Congratulations!"** when done

**Your live URL will be:**
```
https://fixd-terminal.vercel.app
```

or

```
https://fixd-terminal-amadoubbah.vercel.app
```

---

### STEP 6: Test Your Deployment

Click the live URL and verify:

✅ **Dashboard loads** (main screen with heatmap)  
✅ **Bond pricing calculator works** (try entering bond parameters)  
✅ **Yield curve renders** (live Treasury curve visualization)  
✅ **Portfolio risk tab works** (scenario analysis)  
✅ **Credit scoring works** (explainability dashboard)  

**AI Credit Memo tab:** Will show "API key not configured" — that's expected and FINE for your application.

---

## TROUBLESHOOTING

### Error: "Build failed"

**Check the logs:**
1. Click on your deployment
2. Click "View Build Logs"
3. Look for the specific error

**Common fixes:**
- Missing dependencies → Vercel will show which package
- Syntax error in code → Check the line number in logs

### Error: "404 when refreshing page"

**Fix:** vercel.json should have:
```json
{
  "rewrites": [
    { "source": "/api/(.*)", "destination": "/api/$1" },
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

This is already in your project — you're good.

### Error: "Module not found: react"

**Fix:** Make sure package.json has react in dependencies (not devDependencies):
```json
"dependencies": {
  "react": "^18.3.1",
  "react-dom": "^18.3.1",
  "recharts": "^2.13.3"
}
```

This is already correct in your project.

---

## ENABLING AI CREDIT MEMO (OPTIONAL)

If you want the AI feature to work:

1. Get an Anthropic API key from [console.anthropic.com](https://console.anthropic.com)
2. In Vercel: Project Settings → Environment Variables
3. Add: `ANTHROPIC_API_KEY = sk-ant-...your-key...`
4. Redeploy

**For Wealthsimple application, you DON'T need this.** The other features are enough to demonstrate your work.

---

## AFTER SUCCESSFUL DEPLOYMENT

### Update Your Application Materials

**Wealthsimple Question 3:**
```
GitHub: github.com/Amadoubbah
LinkedIn: linkedin.com/in/amadoubah  
FIXD Platform: fixd-terminal.vercel.app

Note: FIXD is a fixed income analytics platform I built to understand 
credit markets. Features include bond pricing, credit risk scoring, 
portfolio analysis, and live yield curves.
```

**Update Your Resume:**
Change this bullet:
```
• Developed full-stack web application for fixed income analytics...
```

To this:
```
• Developed full-stack web application for fixed income analytics 
  (fixd-terminal.vercel.app) featuring bond pricing, credit risk 
  scoring, and real-time yield curve visualization
```

**Update LinkedIn:**
Add to Projects section:
```
FIXD - Fixed Income Analytics Platform
Live demo: fixd-terminal.vercel.app
Code: github.com/Amadoubbah/fixd-terminal

Built a comprehensive web platform for bond pricing, credit risk 
analysis, and portfolio management using React and Recharts.
```

---

## CUSTOM DOMAIN (OPTIONAL)

If you want your own domain like `fixd.amadoubah.com`:

1. Buy domain from Namecheap ($10/year)
2. In Vercel: Settings → Domains → Add Domain
3. Follow DNS configuration instructions

**Not necessary for applications — .vercel.app is fine.**

---

## CONTINUOUS DEPLOYMENT

**Every time you push to GitHub main branch:**
- Vercel automatically rebuilds and redeploys
- Takes 2-3 minutes
- No manual action needed

**To update your site:**
```bash
git add .
git commit -m "Updated features"
git push
```

Vercel does the rest.

---

## WHAT TO EXPECT

**Build time:** 2-3 minutes  
**Deployment:** Automatic  
**Cost:** $0 (Vercel free tier)  
**Custom domain:** Optional ($10/year if you want)  
**Bandwidth:** Unlimited on free tier  
**SSL:** Automatic HTTPS  

---

## YOUR LIVE LINK

Once deployed, your URL will be:

**https://fixd-terminal.vercel.app**

**USE THIS LINK IN YOUR WEALTHSIMPLE APPLICATION**

---

## FINAL CHECKLIST

Before submitting applications:

✅ FIXD is deployed to Vercel  
✅ Live URL works (fixd-terminal.vercel.app)  
✅ Bond pricing calculator loads  
✅ Yield curve renders  
✅ Updated Wealthsimple application with link  
✅ Updated resume with live demo link  
✅ Updated LinkedIn with project  
✅ GitHub repo is public with good README  

---

**Now deploy it and get that link for your applications!**

If you get any errors, paste the error message and I'll help you fix it.
